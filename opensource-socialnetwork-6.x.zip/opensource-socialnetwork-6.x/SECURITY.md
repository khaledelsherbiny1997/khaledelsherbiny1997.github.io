To report a security vulnerability please contact at arsalan@buddyexpress.net directly with detail of the issue including OSSN version. 
