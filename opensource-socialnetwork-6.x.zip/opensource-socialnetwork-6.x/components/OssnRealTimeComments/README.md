# RealTimeComments
Shows if someone typing comments and it will also load latest comments from current time.
It will not load previous comments but the comments that created after the time you loaded the page.
